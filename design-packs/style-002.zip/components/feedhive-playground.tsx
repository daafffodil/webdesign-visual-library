'use client';

import Link from 'next/link';
import {
  useEffect,
  useRef,
  useState,
  type CSSProperties,
  type ReactNode,
} from 'react';
import {
  ArrowRight,
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Code2,
  Copy,
  FileText,
  Globe,
  ImageIcon,
  Layers,
  Link2,
  Menu,
  MessageCircle,
  MoreHorizontal,
  Plus,
  Search,
  Send,
  Sparkles,
  CalendarDays,
  Workflow,
  Bot,
  BarChart3,
  Zap,
  X,
  Play,
  Pause,
  LayoutGrid,
  Users,
  Inbox,
  CheckCircle2,
} from 'lucide-react';
import './feedhive.css';

const modes = [
  'Composer',
  'AI Assistant',
  'Automation',
  'Post Conditions',
  'Smart Scheduling',
  'Social Inbox',
  'Recycle Suggestions',
  'Analytics',
  'AI Design Library',
  'Agent Chat',
  'Code Assistant',
  'API / CLI',
];
const glyphs = [Sparkles, Workflow, Bot, Code2, Zap];
const features = [
  'Idea Studio',
  'Smart Scheduling',
  'Post Conditions',
  'Labels',
  'Recycle Posts',
  'Grid Preview',
  'Collections',
  'Stories',
  'Draft Review',
  'Short Links',
  'Image Studio',
  'Variables',
  'AI Assistant',
  'Content Planner',
  'Inbox',
  'Approval Flows',
  'Automation',
  'Media Library',
  'Templates',
  'Performance',
  'Time Slots',
  'Campaign Tags',
  'Cross-Publishing',
  'AI Captions',
  'Scripts',
  'Triggers',
  'Prediction',
  'Workspace Access',
  'Client Links',
  'Content Score',
  'Team Collab',
  'Composer',
  'Threads',
  'Saved Replies',
  'Ideas',
  'Approvals',
  'Custom Fields',
  'Calendar',
  'Link Tracking',
  'Bulk Scheduling',
  'Video',
  'Post Preview',
  'Team Roles',
  'Content Library',
];
const icons = [
  Sparkles,
  CalendarDays,
  Workflow,
  Layers,
  FileText,
  LayoutGrid,
  Copy,
  Play,
  MessageCircle,
  Link2,
];

export function FeedHivePlayground() {
  const [mode, setMode] = useState(0),
    [cycle, setCycle] = useState(true),
    [logo, setLogo] = useState(0),
    [menu, setMenu] = useState('');
  const [demo, setDemo] = useState(false),
    [demoFrame, setDemoFrame] = useState(0),
    [selected, setSelected] = useState(''),
    [copied, setCopied] = useState(false);
  useEffect(() => {
    if (!demo) return;
    const timer = setInterval(() => setDemoFrame((n) => (n + 1) % 5), 2400);
    return () => clearInterval(timer);
  }, [demo]);
  const rootRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const motion = matchMedia('(prefers-reduced-motion: reduce)');
    if (motion.matches || !cycle) return;
    const timer = setInterval(() => {
      if (document.visibilityState === 'visible')
        setMode((n) => (n + 1) % modes.length);
    }, 4500);
    return () => clearInterval(timer);
  }, [cycle]);
  useEffect(() => {
    const media = matchMedia('(prefers-reduced-motion: reduce)');
    if (media.matches) return;
    const timer = setInterval(
      () => setLogo((n) => (n + 1) % glyphs.length),
      3000,
    );
    return () => clearInterval(timer);
  }, []);
  useEffect(() => {
    if (!menu) return;
    const close = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setMenu('');
    };
    document.addEventListener('keydown', close);
    return () => document.removeEventListener('keydown', close);
  }, [menu]);
  const Logo = glyphs[logo];
  const choose = (i: number) => {
    setMode(i);
    setCycle(false);
  };
  const go = (id: string) => {
    setMenu('');
    rootRef.current
      ?.querySelector(`#${id}`)
      ?.scrollIntoView({ behavior: 'smooth' });
  };
  return (
    <div className="style-002-scope fh" ref={rootRef}>
      <div className="fh-announcement">
        New workspace release:{' '}
        <a href="#fh-workflows">
          Explore connected tools for your next project <ArrowRight size={14} />
        </a>
      </div>
      <header className="fh-header">
        <div className="fh-container fh-nav">
          <a className="fh-brand" href="#fh-top">
            Draftroom
          </a>
          <nav aria-label="Demo navigation">
            {['Product', 'Connections', 'Resources'].map((n) => (
              <button
                key={n}
                aria-expanded={menu === n}
                onClick={() => setMenu(menu === n ? '' : n)}
              >
                {n}
                <ChevronDown size={12} />
              </button>
            ))}
            <a href="#fh-components">Components</a>
          </nav>
          <div className="fh-nav-actions">
            <Link className="fh-login" href="/styles/style-002">
              Library
            </Link>
            <a className="fh-small-primary" href="#fh-demo">
              Try the demo
            </a>
            <button
              className="fh-mobile-toggle"
              aria-label={menu ? 'Close menu' : 'Open menu'}
              aria-expanded={!!menu}
              onClick={() => setMenu(menu ? '' : 'mobile')}
            >
              {menu ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
        {menu && (
          <div
            className={`fh-megamenu ${menu === 'mobile' ? 'fh-mobile-menu' : ''}`}
          >
            <div className="fh-container">
              <div className="fh-mobile-menu-top">
                <b>Draftroom</b>
                <button
                  onClick={() => setMenu('')}
                  aria-label="Close navigation"
                >
                  <X />
                </button>
              </div>
              <div className="fh-mobile-categories">
                {['Product', 'Connections', 'Resources'].map((group, g) => (
                  <details key={group}>
                    <summary>
                      {group}
                      <ChevronDown size={14} />
                    </summary>
                    {(g === 0
                      ? modes.slice(0, 9)
                      : g === 1
                        ? modes.slice(9)
                        : ['Process', 'Features', 'Components']
                    ).map((n) => (
                      <button
                        key={n}
                        onClick={() => {
                          if (g < 2) {
                            choose(modes.indexOf(n));
                            go('fh-top');
                          } else
                            go(
                              {
                                Process: 'fh-process',
                                Features: 'fh-features',
                                Components: 'fh-components',
                              }[n] || 'fh-top',
                            );
                        }}
                      >
                        {n}
                        <ArrowRight size={14} />
                      </button>
                    ))}
                  </details>
                ))}
              </div>
              <div className="fh-menu-grid">
                {[
                  ['Plan & create', 'Composer', 'AI Assistant', 'Automation'],
                  [
                    'Review & improve',
                    'Smart Scheduling',
                    'Social Inbox',
                    'Analytics',
                  ],
                  [
                    'Connect & extend',
                    'Agent Chat',
                    'Code Assistant',
                    'API / CLI',
                  ],
                ].map((col) => (
                  <div key={col[0]}>
                    <p className="fh-kicker">{col[0]}</p>
                    {col.slice(1).map((n) => (
                      <button
                        key={n}
                        onClick={() => {
                          choose(modes.indexOf(n));
                          go('fh-top');
                        }}
                      >
                        <span className="fh-icon-box">
                          <Workflow size={20} />
                        </span>
                        <span>
                          <b>{n}</b>
                          <small>Explore your connected workspace</small>
                        </span>
                      </button>
                    ))}
                  </div>
                ))}
              </div>
              <button className="fh-menu-dismiss" onClick={() => setMenu('')}>
                Close menu
              </button>
            </div>
          </div>
        )}
      </header>
      <section className="fh-hero" id="fh-top">
        <div className="fh-grid-field" />
        <div className="fh-container fh-hero-grid">
          <div className="fh-hero-copy">
            <span className="fh-ring fh-ring-pill">
              <span className="fh-release">
                Introducing Draftroom <small>v2.0</small>
              </span>
            </span>
            <h1>
              Creative work using{' '}
              <span className="fh-logo-badge">
                <Logo key={logo} />
              </span>
              <br />
              <span className="fh-highlight">Automation & AI Agents.</span>
            </h1>
            <ul className="fh-benefits">
              <li>
                <Check />
                <span>
                  <strong>Create with AI.</strong> Shape new ideas around your
                  team’s voice and vision.
                </span>
              </li>
              <li>
                <Check />
                <span>
                  <strong>Automate.</strong> Connect your tools with flexible
                  workflows and conditions.
                </span>
              </li>
              <li>
                <Check />
                <span>
                  <strong>Collaborate.</strong> Bring your team and intelligent
                  tools into one workspace.
                </span>
              </li>
            </ul>
            <div className="fh-actions">
              <span className="fh-ring">
                <a className="fh-primary" href="#fh-demo">
                  Explore the workspace
                </a>
              </span>
              <p>
                Interactive preview.
                <br />
                Make it your own.
              </p>
            </div>
            <div className="fh-picker">
              <p className="fh-kicker">BUILD A WORKSPACE FOR YOUR IDEAS.</p>
              <div className="fh-chips" aria-label="Product previews">
                {modes.map((n, i) => (
                  <button
                    key={n}
                    className={mode === i ? 'is-active' : ''}
                    aria-pressed={mode === i}
                    onClick={() => choose(i)}
                  >
                    {n}
                    {mode === i && (
                      <span className="fh-chip-check">
                        <Check size={12} />
                      </span>
                    )}
                  </button>
                ))}
              </div>
              <button className="fh-cycle" onClick={() => setCycle(!cycle)}>
                {cycle ? <Pause size={12} /> : <Play size={12} />}{' '}
                {cycle ? 'Pause previews' : 'Resume previews'}
              </button>
            </div>
          </div>
          <div className="fh-hero-stage">
            <div className="fh-product-overflow">
              <ProductUI mode={mode} />
            </div>
          </div>
        </div>
      </section>
      <section className="fh-trusted">
        <div className="fh-container fh-trust-grid">
          <p className="fh-kicker">MADE FOR GREAT TEAMS</p>
          <div className="fh-wordmarks">
            {[
              'northstar',
              'forma',
              'prism',
              'OrbitLab',
              'RIVERSIDE',
              'thirdspace',
            ].map((x, i) => (
              <span key={x}>
                <span aria-hidden="true">
                  {['▰', '↗', '▧', '◉', '∿', 'Ⅲ'][i]}
                </span>
                {x}
              </span>
            ))}
          </div>
        </div>
      </section>
      <section className="fh-section fh-steps" id="fh-process">
        <div className="fh-container">
          <Heading label="HOW IT WORKS">
            From the first spark to your next great project.
          </Heading>
          <div className="fh-line-grid fh-step-grid">
            {[
              [
                'Learn your workspace',
                'Connect your sources, preferences, and project goals to build a shared foundation.',
              ],
              [
                'Shape your next idea',
                'Turn your notes into drafts, explore variations, and keep the best ideas.',
              ],
              [
                'Keep things moving',
                'Plan the next step and give every project a clear place on the calendar.',
              ],
            ].map(([t, p], i) => (
              <article key={t}>
                <div className="fh-step-image">
                  <Diagram variant={i} />
                </div>
                <h3>
                  <span>0{i + 1}. </span>
                  {t}
                </h3>
                <p>{p}</p>
              </article>
            ))}
          </div>
        </div>
      </section>
      <section className="fh-section fh-demo" id="fh-demo">
        <div className="fh-container">
          <Heading label="SEE FOR YOURSELF">
            A little less work. A lot more possibility.
          </Heading>
          <div className="fh-video-frame">
            <ProductUI mode={demoFrame} />
            <div className="fh-demo-controls">
              <button
                onClick={() => setDemo(!demo)}
                aria-label={
                  demo ? 'Pause workspace demo' : 'Play workspace demo'
                }
              >
                {demo ? <Pause /> : <Play />}
                <span>{demo ? 'Pause demo' : 'Play demo'}</span>
              </button>
              <span>{modes[demoFrame]}</span>
            </div>
          </div>
        </div>
      </section>
      <section className="fh-section fh-effects">
        <div className="fh-container">
          <Heading label="THE BIGGER PICTURE">
            What happens when your ideas start moving.
          </Heading>
          <div className="fh-quote">
            <span className="fh-avatar">AL</span>
            <p>
              “A shared space gives our best ideas room to become something
              real.”<small>Alex Lee, example workspace</small>
            </p>
          </div>
          <div className="fh-line-grid fh-results">
            {['See steady progress', 'Find your next direction'].map((t, i) => (
              <article key={t}>
                <div className="fh-chart-wrap">
                  <Chart line={i === 1} />
                </div>
                <h3>{t}</h3>
                <p>
                  {i
                    ? 'A clear view of your work helps your team choose the next step.'
                    : 'Small, consistent steps add up to meaningful progress over time.'}
                </p>
              </article>
            ))}
          </div>
        </div>
      </section>
      <section className="fh-section fh-socials" id="fh-connections">
        <div className="fh-container">
          <Heading label="CONNECTED TOOLS">
            Bring all your favorite tools into one place.
          </Heading>
          <div className="fh-social-field">
            {[0, 1, 2].map((row) => (
              <div
                className="fh-social-row"
                key={row}
                style={{ animationDelay: `${row * -4.5}s` }}
              >
                {Array.from({ length: 9 }, (_, i) => {
                  const Icon = icons[(row * 4 + i) % icons.length];
                  const valid =
                    row === 0
                      ? i >= 2 && i < 7
                      : row === 1
                        ? i >= 2 && i < 6
                        : i >= 3 && i < 6;
                  return (
                    <div
                      className={`fh-social-tile ${valid ? '' : 'is-empty'}`}
                      key={i}
                    >
                      {valid && (
                        <span
                          className={`fh-social-icon tone-${(row * 4 + i) % 8}`}
                        >
                          <Icon />
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      </section>
      <section className="fh-section fh-workflows" id="fh-workflows">
        <div className="fh-container">
          <Heading label="AGENTIC WORKFLOWS">
            Your connected workspace for people and agents.
          </Heading>
          <div className="fh-workflow-grid">
            {[
              [
                'Visual workflows',
                'Connect your sources and build flexible pipelines that keep your work moving.',
              ],
              [
                'Agent conversations',
                'Start a conversation and let your assistant prepare the next steps for you.',
              ],
              [
                'Your code workspace',
                'Bring your ideas, drafts, and project context into the tools you already use.',
              ],
              [
                'API / CLI',
                'Connect custom scripts and developer tools to your team’s everyday workflow.',
              ],
            ].map(([t, p], i) => (
              <article key={t}>
                <h3>{t}</h3>
                <p>{p}</p>
                <div className="fh-agent-preview">
                  <ProductUI mode={[2, 9, 10, 11][i]} bare />
                </div>
              </article>
            ))}
          </div>
          <div className="fh-line-grid fh-integration-grid">
            {[
              ['Automation', 'Connect your team’s everyday steps.'],
              ['Agent skills', 'One workspace, many ways to work.'],
              ['App connections', 'Build a bridge to your favorite tools.'],
              ['Workflow recipes', 'Start with a repeatable sequence.'],
              ['Public API', 'Use the same capabilities in your code.'],
              ['MCP connection', 'Make your workspace available to agents.'],
            ].map(([t, p], i) => {
              const Icon = icons[i];
              return (
                <article key={t}>
                  <h3>
                    <Icon size={17} />
                    {t}
                  </h3>
                  <p>{p}</p>
                </article>
              );
            })}
          </div>
        </div>
      </section>
      <section className="fh-section fh-editorial">
        <div className="fh-container">
          <Heading label="A CONNECTED WORKFLOW">
            Everything your team needs to keep moving.
          </Heading>
          <div className="fh-editorial-rows">
            {[
              [
                'One idea. Many possibilities.',
                'Adapt your original idea into the formats you need, while keeping the details that make it yours.',
              ],
              [
                'Keep your work and team aligned.',
                'Review drafts, share feedback, and give your team a clear view of what comes next.',
              ],
              [
                'Let your schedule work in the background.',
                'Set repeatable rules and keep your projects moving without starting from scratch every day.',
              ],
            ].map(([t, p], i) => (
              <article key={t}>
                <div className="fh-editorial-visual">
                  <Diagram variant={i + 3} />
                </div>
                <div className="fh-editorial-copy">
                  <h3>{t}</h3>
                  <p>{p}</p>
                  <button
                    className="fh-secondary"
                    onClick={() => {
                      choose([0, 1, 4][i]);
                      go('fh-top');
                    }}
                  >
                    Explore workspace
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
      <section className="fh-section fh-features" id="fh-features">
        <div className="fh-wall-container">
          <Heading label="FEATURES">
            Powerful details for the way you like to work.
          </Heading>
          <FeatureWall onSelect={setSelected} />
          {selected && (
            <output className="fh-selected">
              {selected} selected{' '}
              <button onClick={() => setSelected('')}>Dismiss</button>
            </output>
          )}
        </div>
      </section>
      <section className="fh-cta-section">
        <div className="fh-cta">
          <div className="fh-cta-top">
            <div>
              <p className="fh-kicker">GET STARTED.</p>
              <h2>
                Give your next big idea a workspace where it can come to life.
              </h2>
            </div>
            <div className="fh-actions">
              <a className="fh-white-button" href="#fh-demo">
                Open the workspace
              </a>
              <p>
                Explore the demo.
                <br />
                Build something new.
              </p>
            </div>
          </div>
          <div className="fh-wordmarks">
            {[
              'northstar',
              'forma',
              'prism',
              'OrbitLab',
              'RIVERSIDE',
              'thirdspace',
            ].map((x) => (
              <span key={x}>{x}</span>
            ))}
          </div>
          <div className="fh-cta-ui">
            <ProductUI mode={1} />
          </div>
        </div>
      </section>
      <footer className="fh-footer">
        <div className="fh-container">
          <div className="fh-footer-grid">
            <div>
              <b className="fh-brand">Draftroom</b>
              <p>
                A shared home for ideas, projects, and the people who make them
                happen.
              </p>
              <div className="fh-chips">
                <span>Shared workspace</span>
                <span>Connected tools</span>
                <span>Team collaboration</span>
              </div>
            </div>
            {[
              ['Workspace', 'Composer', 'Calendar', 'Automation'],
              ['Resources', 'Design system', 'Reference', 'Agent pack'],
              ['Guides', 'Process', 'Connections', 'Features'],
              ['Project', 'Components', 'Source website', 'Back to library'],
            ].map((col) => (
              <div key={col[0]}>
                <h3>{col[0]}</h3>
                {col.slice(1).map((t, i) => (
                  <a
                    key={t}
                    href={
                      col[0] === 'Resources'
                        ? `/styles/style-002?tab=${['design-system', 'reference', 'agent'][i]}`
                        : col[0] === 'Guides'
                          ? ['#fh-process', '#fh-connections', '#fh-features'][
                              i
                            ]
                          : col[0] === 'Project'
                            ? [
                                '#fh-components',
                                'https://www.feedhive.com/',
                                '/',
                              ][i]
                            : '#fh-top'
                    }
                  >
                    {t}
                  </a>
                ))}
              </div>
            ))}
          </div>
          <div className="fh-footer-bottom">
            <span>Style 002, neutral demonstration</span>
            <a href="#fh-top">Back to top ↑</a>
          </div>
        </div>
      </footer>
      <section className="fh-component-lab" id="fh-components">
        <div className="fh-container">
          <h2>Component workbench</h2>
          <div className="fh-lab-grid">
            <div>
              <h3>Buttons & states</h3>
              <div className="fh-lab-row">
                <span className="fh-ring">
                  <button
                    className="fh-primary"
                    onClick={() => setCopied(true)}
                  >
                    {copied ? (
                      <>
                        <Check size={16} /> Selected
                      </>
                    ) : (
                      'Primary action'
                    )}
                  </button>
                </span>
                <button
                  className="fh-secondary"
                  onClick={() => setCopied(false)}
                >
                  Reset
                </button>
                <button className="fh-primary" disabled>
                  Disabled
                </button>
              </div>
            </div>
            <div>
              <h3>Editable product UI</h3>
              <label className="fh-field">
                Workspace name
                <input
                  defaultValue="Creative workspace"
                  placeholder="Workspace name"
                />
              </label>
              <label className="fh-field">
                Notes
                <textarea defaultValue="Make room for the next great idea." />
              </label>
            </div>
          </div>
          <p className="fh-lab-note">
            Page geometry and motion use measured source values. Editable
            product illustrations, demo controls, disabled states and form
            fields are reconstructed.
          </p>
        </div>
      </section>
    </div>
  );
}

export function Heading({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <div className="fh-section-heading">
      <p className="fh-kicker">{label}</p>
      <h2>{children}</h2>
    </div>
  );
}

function WindowBar() {
  return (
    <div className="fh-window-bar">
      <span className="fh-window-dots">
        <i />
        <i />
        <i />
      </span>
      <LayoutGrid size={16} />
      <ChevronLeft size={16} />
      <ChevronRight size={16} />
      <span className="fh-address">
        <Layers size={14} />
        <i />
      </span>
      <Plus size={18} />
    </div>
  );
}

export function ProductUI({
  mode = 0,
  bare = false,
}: {
  mode?: number;
  bare?: boolean;
}) {
  return (
    <div
      className={`fh-product-ui ${bare ? 'fh-ui-bare' : ''}`}
      data-preview={modes[mode]}
    >
      {!bare && <WindowBar />}
      <div className="fh-ui-content">
        {mode === 0 && (
          <>
            <div className="fh-composer">
              <div className="fh-ui-toolbar">
                <span>☰</span>
                <Plus size={14} />
                <span className="fh-push">● Draft</span>
              </div>
              <div className="fh-paper">
                <div className="fh-mini-title">
                  <span className="fh-icon-box">
                    <FileText />
                  </span>
                  <div>
                    <b>Create a draft</b>
                    <small>Turn an idea into something worth sharing.</small>
                  </div>
                </div>
                <div className="fh-draft-text">
                  <p>Good ideas deserve a little room to grow.</p>
                  <p>
                    A place for your notes. A space for your team.
                    <br />A clear path from the first thought to the finished
                    work.
                  </p>
                  <p>
                    Bring the pieces together, explore a new direction, and make
                    something you’re proud to share.
                  </p>
                  <small className="fh-counter">2685</small>
                  <div className="fh-mini-tools">
                    <MoreHorizontal />
                    <MessageCircle />
                    <ImageIcon />
                    <Sparkles />
                    <Plus />
                  </div>
                </div>
                <div className="fh-thumbnail-row">
                  {Array.from({ length: 9 }, (_, i) => (
                    <div key={i}>
                      <small>IDEA {i + 1}</small>
                      <span>
                        Make room
                        <br />
                        for better
                        <br />
                        work.
                      </span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="fh-ui-two">
                <div className="fh-paper">
                  <b>Readiness score</b>
                  <small>Your next step is looking good.</small>
                  <div className="fh-gauge">68</div>
                </div>
                <div className="fh-paper">
                  <b>Explore directions</b>
                  <small>Three ways to develop your idea.</small>
                  <div className="fh-mini-swatches">
                    <i />
                    <i />
                    <i />
                  </div>
                </div>
              </div>
            </div>
            <aside className="fh-ui-side">
              <Search size={18} />
              <div className="fh-paper">
                <b>Project context</b>
                <p>Keep the whole picture in view.</p>
                <span className="fh-mini-pill">In progress</span>
              </div>
            </aside>
          </>
        )}
        {mode === 1 && (
          <>
            <div className="fh-chat-ui">
              <div className="fh-bubble">
                Hi there
                <br />
                <br />
                What would you like to work on today?
              </div>
              <div className="fh-bubble mine">
                Help me shape a plan for the next project.
              </div>
              <div className="fh-bubble">
                Here’s a starting point for your team.
                <br />
                <br />
                <span className="fh-mini-pill">✓ Accept draft</span>
              </div>
              <div className="fh-bubble mine">
                Let’s make the introduction a little clearer.
              </div>
            </div>
            <div className="fh-paper fh-review">
              <div className="fh-mini-title">
                <FileText />
                <b>Create a draft</b>
              </div>
              <p>Bring your best ideas together in one place.</p>
              <p>
                <del>A long list of disconnected tasks.</del>
                <br />
                <ins>A clear plan for your next great project.</ins>
              </p>
              <p>
                <del>Too many tools, too little context.</del>
                <br />
                <ins>One shared space for your whole team.</ins>
              </p>
              <p>Start with the first step. Build from there.</p>
            </div>
          </>
        )}
        {(mode === 2 || mode === 3) && (
          <div className="fh-flow-canvas">
            <div className="fh-flow-row">
              <div className="fh-flow-node">
                <Link2 /> Workspace URL
              </div>
              <ArrowRight />
              <div className="fh-flow-node">
                <Sparkles /> Create draft
              </div>
            </div>
            <div className="fh-flow-connector" />
            <div className="fh-flow-row">
              <div className="fh-flow-node">
                <Users /> Add people
              </div>
              <span className="fh-flow-caption">
                {mode === 3 ? 'If score > 80' : 'Then'}
              </span>
            </div>
            <div className="fh-flow-connector" />
            <div className="fh-flow-row">
              <div className="fh-flow-node">
                <Layers /> Add labels
              </div>
              <ArrowRight />
              <div className="fh-flow-node active">
                <Send /> Publish
              </div>
            </div>
          </div>
        )}
        {mode === 4 && (
          <div className="fh-calendar-ui">
            <div className="fh-calendar-head">
              September <span>Week view</span>
            </div>
            <div className="fh-calendar-grid">
              {['Monday', 'Tuesday', 'Wednesday', 'Thursday'].map((n, i) => (
                <div key={n}>
                  <b>{n}</b>
                  <small>{19 + i}.09</small>
                  {[0, 1, 2].map((j) => (
                    <div
                      className={`fh-time-slot ${(j + i) % 2 ? 'filled' : ''}`}
                      key={j}
                    >
                      {(j + i) % 2 ? 'Project slot' : 'Open slot'}
                    </div>
                  ))}
                </div>
              ))}
            </div>
            <div className="fh-schedule-dialog fh-paper">
              <b>Generate a weekly plan</b>
              <p>Choose a pace that works for you.</p>
              {['Relaxed', 'Balanced', 'Focused'].map((n, i) => (
                <div className={i === 1 ? 'is-selected' : ''} key={n}>
                  <b>✧ {n}</b>
                  <small>
                    {i + 1}–{i + 3} projects / week
                  </small>
                </div>
              ))}
              <span className="fh-mini-primary">Generate plan</span>
            </div>
          </div>
        )}
        {(mode === 5 || mode === 6) && (
          <div className="fh-inbox-ui">
            <div className="fh-mini-title">
              <Inbox />
              <b>{mode === 5 ? 'Team inbox' : 'Suggested next steps'}</b>
            </div>
            <div className="fh-ui-toolbar">
              New <span>Reviewed</span>
              <span>Archived</span>
            </div>
            {[
              'A little feedback on the latest draft',
              'Your next project is ready for review',
              'Bring this idea back into the conversation',
            ].map((n, i) => (
              <div className="fh-paper" key={n}>
                <span className="fh-avatar">{['AL', 'MK', 'JS'][i]}</span>
                <div>
                  <b>{n}</b>
                  <p>
                    Keep the details together and move the conversation forward.
                  </p>
                  <span className="fh-mini-pill">
                    {mode === 5 ? 'Reply' : 'Add to workspace'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
        {mode === 7 && (
          <div className="fh-analytics-ui">
            <div className="fh-mini-title">
              <BarChart3 />
              <b>Workspace overview</b>
            </div>
            <div className="fh-ui-two">
              <div className="fh-paper">
                <small>Projects completed</small>
                <h3>1,284</h3>
                <span className="fh-positive">↗ 24.8%</span>
              </div>
              <div className="fh-paper">
                <small>Team activity</small>
                <h3>86.4%</h3>
                <span className="fh-positive">↗ 12.6%</span>
              </div>
            </div>
            <Chart line />
          </div>
        )}
        {mode === 8 && (
          <div className="fh-gallery-ui">
            <div className="fh-mini-title">
              <ImageIcon />
              <b>Design library</b>
            </div>
            <div className="fh-gallery-grid">
              {Array.from({ length: 9 }, (_, i) => (
                <div className={`tone-${i % 8}`} key={i}>
                  <small>COLLECTION 0{i + 1}</small>
                  <b>
                    {
                      [
                        'Shape your next idea',
                        'A fresh perspective',
                        'Make space for more',
                      ][i % 3]
                    }
                  </b>
                  <span>Explore →</span>
                </div>
              ))}
            </div>
          </div>
        )}
        {mode === 9 && (
          <div className="fh-agent-chat">
            <div className="fh-agent-chat-head">
              <Bot />
              <b>Workspace Agent</b>
              <small>last seen just now</small>
            </div>
            <div className="fh-bubble">Should we prepare the next project?</div>
            <div className="fh-bubble mine">Yes, let’s plan the week.</div>
            <div className="fh-bubble">
              <b>Your plan is ready</b>
              <p>3 ideas, 5 drafts, 1 shared calendar.</p>
              <span className="fh-mini-pill">Open project →</span>
            </div>
          </div>
        )}
        {mode === 10 && (
          <div className="fh-terminal">
            <div className="fh-terminal-dots">● ● ●</div>
            <p>
              <em>$</em> npx workspace connect
            </p>
            <p>
              {' '}
              ✓ Workspace tools installed
              <br /> ✓ Project context available
            </p>
            <br />
            <p>
              <em>$</em> assistant
            </p>
            <p className="fh-terminal-box">
              Workspace detected
              <br />
              <span>Ready to create, review and organize.</span>
            </p>
            <p>
              › Prepare the next project for review
              <span className="fh-cursor">▍</span>
            </p>
          </div>
        )}
        {mode === 11 && (
          <pre className="fh-code">
            <span>const</span>
            {` project = await workspace.create({\n  name: 'The next great idea',\n  status: 'draft',\n  content: {\n    title: 'A fresh perspective',\n    team: ['design', 'studio'],\n    steps: [\n      'Explore the possibilities',\n      'Share an early draft',\n      'Make something together'\n    ]\n  }\n});\n\nawait project.schedule();`}
          </pre>
        )}
      </div>
    </div>
  );
}

function MiniCard({
  title,
  children,
  className = '',
}: {
  title: string;
  children?: ReactNode;
  className?: string;
}) {
  return (
    <div className={`fh-mini-card ${className}`}>
      <b>{title}</b>
      {children}
    </div>
  );
}
export function Diagram({ variant }: { variant: number }) {
  return (
    <div className={`fh-diagram fh-diagram-${variant}`}>
      {variant === 0 && (
        <>
          <div className="fh-diagram-inputs">
            <MiniCard title="Website">
              <span className="fh-mini-input">
                <Globe />
                yourworkspace.com
              </span>
            </MiniCard>
            <MiniCard title="Connections">
              <div className="fh-mini-tools">
                <Globe />
                <MessageCircle />
                <Users />
                <ImageIcon />
              </div>
            </MiniCard>
            <MiniCard title="Your voice">
              <div className="fh-mini-tags">
                <span>Helpful</span>
                <span>Clear</span>
                <span>Creative</span>
              </div>
            </MiniCard>
          </div>
          <ArrowRight className="fh-diagram-arrow" />
          <MiniCard title="Workspace profile" className="fh-profile">
            <Sparkles />
            {['Voice', 'Audience', 'Topics'].map((t) => (
              <div className="fh-profile-item" key={t}>
                <CheckCircle2 />
                <div>
                  <b>{t}</b>
                  <small>Clear, thoughtful, on-brand</small>
                </div>
              </div>
            ))}
          </MiniCard>
        </>
      )}
      {variant === 1 && (
        <>
          <MiniCard title="Workspace" className="fh-floating-profile">
            <small>
              ● Voice
              <br />● Audience
              <br />● Topics
            </small>
          </MiniCard>
          <div className="fh-card-stack">
            <MiniCard title="First direction" />
            <MiniCard title="Another possibility" />
            <MiniCard title="Your next idea is ready">
              <p>
                Turn a thought into a starting point.
                <br />
                Give the next step a little clarity.
              </p>
              <div className="fh-mini-tags">
                <span>On-brand</span>
                <span>Ready</span>
                <span>3 variations</span>
              </div>
              <div className="fh-mini-tools">
                <Globe />
                <MessageCircle />
                <Users />
                <ImageIcon />
              </div>
            </MiniCard>
          </div>
          <span className="fh-ai-orb">
            <Sparkles />
          </span>
        </>
      )}
      {variant === 2 && (
        <MiniCard title="Weekly schedule" className="fh-weekly">
          {['Mon', 'Tue', 'Wed', 'Thu', 'Fri'].map((d, i) => (
            <div className="fh-week-row" key={d}>
              <span>{d}</span>
              <Check />
              <b>Project ready</b>
              <span className={`fh-week-icon tone-${i}`}>
                {i % 2 ? <Users /> : <Globe />}
              </span>
              <small>{9 + i}:00</small>
            </div>
          ))}
        </MiniCard>
      )}
      {variant === 3 && (
        <div className="fh-editor-frame">
          <MiniCard title="Original idea">
            <div className="fh-file-tile">
              <ImageIcon />
            </div>
            <b>Your next draft</b>
            <small>Your content is prepared.</small>
          </MiniCard>
          <div className="fh-adapt">
            <span>✧ Adapt</span>
            <ArrowRight />
          </div>
          <div className="fh-adapt-grid">
            {['Story', 'Project', 'Note', 'Presentation'].map((t) => (
              <MiniCard title={t} key={t}>
                <div className="fh-placeholder-lines" />
                <small>Ready to share</small>
              </MiniCard>
            ))}
          </div>
        </div>
      )}
      {variant === 4 && (
        <div className="fh-editor-frame">
          <MiniCard title="Project preview" className="fh-review-card">
            <div className="fh-file-tile">
              <ImageIcon />
            </div>
            <b>Ready for review</b>
            <p>Your new project draft</p>
            <div className="fh-mini-tools">
              <Globe />
              <Users />
              <MessageCircle />
            </div>
          </MiniCard>
          <MiniCard title="Review" className="fh-floating-review">
            <p>Looks good</p>
            <p>Ready to share</p>
          </MiniCard>
          <div className="fh-approved">
            <CheckCircle2 /> Approved
          </div>
        </div>
      )}
      {variant === 5 && (
        <div className="fh-editor-frame">
          <MiniCard title="Workspace rules">
            <div className="fh-rule">
              Best time <span>On</span>
            </div>
            <div className="fh-rule">
              Repeat ideas <span>On</span>
            </div>
            <div className="fh-rule">
              Conditions <span>On</span>
            </div>
          </MiniCard>
          <ArrowRight className="fh-diagram-arrow" />
          <MiniCard title="Project queue" className="fh-queue">
            {[
              'Design review',
              'Weekly notes',
              'New direction',
              'Project analysis',
              'Team update',
            ].map((t) => (
              <div className="fh-queue-item" key={t}>
                <FileText />
                {t}
                <small>Today</small>
              </div>
            ))}
            <span className="fh-positive">✓ Running automatically</span>
          </MiniCard>
        </div>
      )}
    </div>
  );
}

export function Chart({ line = false }: { line?: boolean }) {
  return (
    <div className="fh-chart">
      <div className="fh-chart-title">
        {line ? 'Projects by team over time' : 'WORKSPACE PROGRESS'}
        <span>{line ? '5k' : 'Hours　 Days'}</span>
      </div>
      {line ? (
        <svg
          viewBox="0 0 540 340"
          aria-label="Example line chart showing project progress"
        >
          <g stroke="#eceef3">
            {[60, 120, 180, 240, 300].map((y) => (
              <path key={y} d={`M10 ${y}H510`} />
            ))}
          </g>
          {['#457e9a', '#6997ed', '#7062bc', '#a77bbe'].map((c, i) => (
            <polyline
              key={c}
              fill="none"
              stroke={c}
              strokeWidth="2"
              points={`10,300 60,297 110,300 165,296 220,298 270,300 300,${240 + i * 13} 328,${205 + i * 19} 355,${226 + i * 14} 382,${158 + i * 20} 410,${183 + i * 15} 438,${110 + i * 19} 465,${126 + i * 15} 510,${20 + i * 32}`}
            />
          ))}
        </svg>
      ) : (
        <>
          <p className="fh-chart-month">〈September〉</p>
          <div className="fh-bars">
            {[
              3, 4, 4, 5, 4, 4, 6, 5, 6, 5, 5, 6, 9, 24, 29, 33, 37, 44, 55, 60,
              66, 77, 88, 96,
            ].map((h, i) => (
              <i key={i} style={{ height: `${h}%` }} />
            ))}
          </div>
        </>
      )}
      <div className="fh-chart-axis">
        <span>1st</span>
        <span>5th</span>
        <span>10th</span>
        <span>15th</span>
        <span>20th</span>
        <span>25th</span>
        <span>30th</span>
      </div>
      <div className="fh-chart-legend">
        {line
          ? '● Studio　 ● Design　 ● Product　 ● Research'
          : 'Your progress at a glance'}
      </div>
    </div>
  );
}

const wallCards = [
  [
    'Image Studio',
    'Explore fresh visual directions for your next idea.',
    '244,161,189,.28',
    '#ffe9ef',
    '#df6b85',
  ],
  [
    'Creative Assistant',
    'Turn the first thought into a draft you can build on.',
    '222,196,255,.32',
    '#f1edff',
    '#7f67ff',
  ],
  [
    'Idea Recycling',
    'Bring your best work back into the conversation.',
    '254,214,98,.28',
    '#fff4d8',
    '#d2a23d',
  ],
  [
    'Connected Links',
    'Keep your references close and your projects connected.',
    '174,223,184,.28',
    '#d3f3d8',
    '#62a977',
  ],
];
export function FeatureWall({
  onSelect = () => {},
}: {
  onSelect?: (s: string) => void;
}) {
  let index = 0;
  return (
    <div className="fh-wall">
      <div className="fh-wall-grid">
        {Array.from({ length: 80 }, (_, i) => {
          const row = Math.floor(i / 10) + 1,
            col = (i % 10) + 1;
          if (row >= 3 && row <= 6 && col >= 4 && col <= 7) return null;
          const empty = row === 1 || row === 8;
          const n = features[(empty ? 0 : index++) % features.length],
            Icon = icons[i % icons.length];
          return (
            <div
              className={`fh-wall-cell ${empty ? 'is-empty' : ''}`}
              key={i}
              style={{ gridColumn: col, gridRow: row }}
            >
              {!empty && (
                <>
                  <Icon size={19} />
                  <span>{n}</span>
                </>
              )}
            </div>
          );
        })}
        {wallCards.map(([t, p, color, bg, ink], i) => {
          const Icon = [Sparkles, MessageCircle, Layers, Link2][i];
          return (
            <button
              className="fh-wall-card"
              onClick={() => onSelect(t)}
              key={t}
              style={
                {
                  gridColumn: `${i % 2 ? 6 : 4} / span 2`,
                  gridRow: `${i < 2 ? 3 : 5} / span 2`,
                  '--card-glow': `rgba(${color})`,
                  '--icon-bg': bg,
                  '--icon-ink': ink,
                } as CSSProperties
              }
            >
              <span className="fh-wall-icon">
                <Icon size={19} />
              </span>
              <h3>{t}</h3>
              <p>{p}</p>
            </button>
          );
        })}
      </div>
    </div>
  );
}
